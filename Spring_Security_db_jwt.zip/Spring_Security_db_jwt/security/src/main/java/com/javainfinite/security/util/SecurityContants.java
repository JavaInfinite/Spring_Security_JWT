package com.javainfinite.security.util;

public class SecurityContants {

    public static final String JWT_KEY = "jxgEQe.XHuPq8VdbyYFNkAN.dudQ0903YUn4";
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String REFRESH_HEADER = "RefreshToken";
}
